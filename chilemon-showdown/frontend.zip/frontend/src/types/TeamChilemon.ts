export interface TeamChilemon {
    id: string;
    teamId: string;
    pokemonId: number;
    position: number;
    nickname: string;
    level: number;
    moves: number[];
    effort: number[];
};