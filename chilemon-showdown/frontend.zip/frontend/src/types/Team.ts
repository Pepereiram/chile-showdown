export interface Team {
    id: string;
    userId: string;
    name: string;
}
