export default {
  plugins: {
    "@tailwindcss/postcss": {},  // 👈 nuevo plugin correcto
    autoprefixer: {},
  },
};
